import { z } from "zod";

export const ProductSchema = z.object({
  name: z.string().min(3),
  description: z.string().optional(),
  price: z.number().positive(),
  // promotionPrice: z.number().positive().optional(),
  quantity: z.number().int().positive(),
  category: z.string(),
  images: z.array(z.string()).optional(),
});
